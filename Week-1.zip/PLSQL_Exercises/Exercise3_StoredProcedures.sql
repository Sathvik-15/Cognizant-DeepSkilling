-- Exercise 3: Stored Procedures

-- Scenario 1
CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest AS
BEGIN
    UPDATE Accounts 
    SET balance = balance + (balance * 0.01) 
    WHERE account_type = 'SAVINGS';
    COMMIT;
END ProcessMonthlyInterest;
/

-- Scenario 2
CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    p_department_id IN NUMBER,
    p_bonus_percentage IN NUMBER
) AS
BEGIN
    UPDATE Employees 
    SET salary = salary + (salary * (p_bonus_percentage / 100)) 
    WHERE department_id = p_department_id;
    COMMIT;
END UpdateEmployeeBonus;
/

-- Scenario 3
CREATE OR REPLACE PROCEDURE TransferFunds (
    p_from_account IN NUMBER,
    p_to_account IN NUMBER,
    p_amount IN NUMBER
) AS
    v_balance NUMBER;
BEGIN
    SELECT balance INTO v_balance FROM Accounts WHERE account_id = p_from_account FOR UPDATE;
    IF v_balance >= p_amount THEN
        UPDATE Accounts SET balance = balance - p_amount WHERE account_id = p_from_account;
        UPDATE Accounts SET balance = balance + p_amount WHERE account_id = p_to_account;
        COMMIT;
    ELSE
        DBMS_OUTPUT.PUT_LINE('Insufficient balance.');
    END IF;
END TransferFunds;
/
