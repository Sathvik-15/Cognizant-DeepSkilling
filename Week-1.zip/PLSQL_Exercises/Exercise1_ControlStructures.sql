-- Exercise 1: Control Structures

-- Scenario 1
DECLARE
    CURSOR c_customers IS SELECT customer_id, age FROM Customers WHERE age > 60;
BEGIN
    FOR rec IN c_customers LOOP
        UPDATE Loans SET interest_rate = interest_rate - 0.01 WHERE customer_id = rec.customer_id;
    END LOOP;
    COMMIT;
END;
/

-- Scenario 2
DECLARE
    CURSOR c_customers IS SELECT customer_id, balance FROM Customers;
BEGIN
    FOR rec IN c_customers LOOP
        IF rec.balance > 10000 THEN
            UPDATE Customers SET IsVIP = 'TRUE' WHERE customer_id = rec.customer_id;
        END IF;
    END LOOP;
    COMMIT;
END;
/

-- Scenario 3
DECLARE
    CURSOR c_loans IS SELECT customer_id, due_date FROM Loans WHERE due_date <= SYSDATE + 30;
BEGIN
    FOR rec IN c_loans LOOP
        DBMS_OUTPUT.PUT_LINE('Reminder for Customer ' || rec.customer_id || ': Loan is due on ' || rec.due_date);
    END LOOP;
END;
/
