class Computer {
    private String CPU;
    private String RAM;
    private String storage;
    
    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
    }
    
    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", storage=" + storage + "]";
    }
    
    public static class Builder {
        private String CPU;
        private String RAM;
        private String storage;
        
        public Builder setCPU(String CPU) { this.CPU = CPU; return this; }
        public Builder setRAM(String RAM) { this.RAM = RAM; return this; }
        public Builder setStorage(String storage) { this.storage = storage; return this; }
        public Computer build() { return new Computer(this); }
    }
}
public class Exercise3_Builder {
    public static void run() {
        System.out.println("--- Exercise 3: Builder Pattern ---");
        Computer comp = new Computer.Builder().setCPU("Intel i7").setRAM("16GB").setStorage("512GB SSD").build();
        System.out.println(comp);
        System.out.println();
    }
}
