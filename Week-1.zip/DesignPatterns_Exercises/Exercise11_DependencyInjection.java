interface CustomerRepository { String findCustomerById(String id); }
class CustomerRepositoryImpl implements CustomerRepository {
    public String findCustomerById(String id) { return "Customer " + id; }
}
class CustomerService {
    private CustomerRepository repository;
    public CustomerService(CustomerRepository repository) { this.repository = repository; }
    public void printCustomer(String id) { System.out.println(repository.findCustomerById(id)); }
}
public class Exercise11_DependencyInjection {
    public static void run() {
        System.out.println("--- Exercise 11: Dependency Injection ---");
        CustomerRepository repo = new CustomerRepositoryImpl();
        CustomerService service = new CustomerService(repo);
        service.printCustomer("501");
        System.out.println();
    }
}
