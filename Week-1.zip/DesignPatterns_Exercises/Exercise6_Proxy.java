interface Image { void display(); }
class RealImage implements Image {
    private String filename;
    public RealImage(String filename) { this.filename = filename; loadFromDisk(); }
    private void loadFromDisk() { System.out.println("Loading " + filename); }
    public void display() { System.out.println("Displaying " + filename); }
}
class ProxyImage implements Image {
    private RealImage realImage;
    private String filename;
    public ProxyImage(String filename) { this.filename = filename; }
    public void display() {
        if (realImage == null) realImage = new RealImage(filename);
        realImage.display();
    }
}
public class Exercise6_Proxy {
    public static void run() {
        System.out.println("--- Exercise 6: Proxy Pattern ---");
        Image image = new ProxyImage("test_image.jpg");
        image.display(); // Loads and displays
        image.display(); // Only displays (cached)
        System.out.println();
    }
}
