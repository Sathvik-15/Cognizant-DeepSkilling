interface Document { void open(); }
class WordDocument implements Document { public void open() { System.out.println("Opening Word document."); } }
class PdfDocument implements Document { public void open() { System.out.println("Opening PDF document."); } }
class ExcelDocument implements Document { public void open() { System.out.println("Opening Excel document."); } }

abstract class DocumentFactory {
    public abstract Document createDocument(String type);
}

class ConcreteDocumentFactory extends DocumentFactory {
    @Override
    public Document createDocument(String type) {
        if (type.equalsIgnoreCase("Word")) return new WordDocument();
        else if (type.equalsIgnoreCase("Pdf")) return new PdfDocument();
        else if (type.equalsIgnoreCase("Excel")) return new ExcelDocument();
        return null;
    }
}

public class Exercise2_Factory {
    public static void run() {
        System.out.println("--- Exercise 2: Factory Method Pattern ---");
        DocumentFactory factory = new ConcreteDocumentFactory();
        Document doc1 = factory.createDocument("Word");
        doc1.open();
        Document doc2 = factory.createDocument("Pdf");
        doc2.open();
        System.out.println();
    }
}
