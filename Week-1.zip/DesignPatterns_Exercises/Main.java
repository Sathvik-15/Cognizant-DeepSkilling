public class Main {
    public static void main(String[] args) {
        System.out.println("Executing Design Patterns Exercises\n=================================\n");
        Exercise1_Singleton.run();
        Exercise2_Factory.run();
        Exercise3_Builder.run();
        Exercise4_Adapter.run();
        Exercise5_Decorator.run();
        Exercise6_Proxy.run();
        Exercise7_Observer.run();
        Exercise8_Strategy.run();
        Exercise9_Command.run();
        Exercise10_MVC.run();
        Exercise11_DependencyInjection.run();
    }
}
