class Logger {
    private static Logger instance;
    private Logger() {}
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }
    public void log(String message) {
        System.out.println("[LOG]: " + message);
    }
}
public class Exercise1_Singleton {
    public static void run() {
        System.out.println("--- Exercise 1: Singleton Pattern ---");
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        logger1.log("This is a log message.");
        System.out.println("Are logger1 and logger2 the same instance? " + (logger1 == logger2));
        System.out.println();
    }
}
