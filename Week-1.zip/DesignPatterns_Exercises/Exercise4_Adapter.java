interface PaymentProcessor { void processPayment(double amount); }
class StripeGateway { public void makePayment(double amount) { System.out.println("Processing $" + amount + " via Stripe."); } }
class StripeAdapter implements PaymentProcessor {
    private StripeGateway stripe;
    public StripeAdapter(StripeGateway stripe) { this.stripe = stripe; }
    public void processPayment(double amount) { stripe.makePayment(amount); }
}
public class Exercise4_Adapter {
    public static void run() {
        System.out.println("--- Exercise 4: Adapter Pattern ---");
        PaymentProcessor processor = new StripeAdapter(new StripeGateway());
        processor.processPayment(100.0);
        System.out.println();
    }
}
