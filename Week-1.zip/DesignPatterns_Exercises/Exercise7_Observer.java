import java.util.ArrayList;
import java.util.List;
interface Observer { void update(double price); }
interface Stock { void register(Observer o); void deregister(Observer o); void notifyObservers(); }
class StockMarket implements Stock {
    private List<Observer> observers = new ArrayList<>();
    private double price;
    public void register(Observer o) { observers.add(o); }
    public void deregister(Observer o) { observers.remove(o); }
    public void notifyObservers() { for (Observer o : observers) o.update(price); }
    public void setPrice(double price) { this.price = price; notifyObservers(); }
}
class MobileApp implements Observer { public void update(double price) { System.out.println("MobileApp notified. New Price: " + price); } }
class WebApp implements Observer { public void update(double price) { System.out.println("WebApp notified. New Price: " + price); } }
public class Exercise7_Observer {
    public static void run() {
        System.out.println("--- Exercise 7: Observer Pattern ---");
        StockMarket market = new StockMarket();
        Observer app1 = new MobileApp();
        Observer app2 = new WebApp();
        market.register(app1);
        market.register(app2);
        market.setPrice(150.5);
        market.setPrice(155.0);
        System.out.println();
    }
}
