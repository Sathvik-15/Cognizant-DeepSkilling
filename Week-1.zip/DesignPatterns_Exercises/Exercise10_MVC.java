class Student {
    private String name;
    private String id;
    private String grade;
    public Student(String name, String id, String grade) { this.name = name; this.id = id; this.grade = grade; }
    public String getName() { return name; } public void setName(String name) { this.name = name; }
    public String getId() { return id; }
    public String getGrade() { return grade; } public void setGrade(String grade) { this.grade = grade; }
}
class StudentView {
    public void displayStudentDetails(String studentName, String studentId, String studentGrade) {
        System.out.println("Student: ");
        System.out.println("Name: " + studentName);
        System.out.println("ID: " + studentId);
        System.out.println("Grade: " + studentGrade);
    }
}
class StudentController {
    private Student model;
    private StudentView view;
    public StudentController(Student model, StudentView view) { this.model = model; this.view = view; }
    public void setStudentName(String name) { model.setName(name); }
    public void setStudentGrade(String grade) { model.setGrade(grade); }
    public void updateView() { view.displayStudentDetails(model.getName(), model.getId(), model.getGrade()); }
}
public class Exercise10_MVC {
    public static void run() {
        System.out.println("--- Exercise 10: MVC Pattern ---");
        Student model = new Student("Alice", "101", "A");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);
        controller.updateView();
        controller.setStudentGrade("A+");
        System.out.println("After updating grade:");
        controller.updateView();
        System.out.println();
    }
}
