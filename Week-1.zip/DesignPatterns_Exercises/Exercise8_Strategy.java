interface PaymentStrategy { void pay(double amount); }
class CreditCardPayment implements PaymentStrategy { public void pay(double amount) { System.out.println("Paid $" + amount + " using Credit Card."); } }
class PayPalPayment implements PaymentStrategy { public void pay(double amount) { System.out.println("Paid $" + amount + " using PayPal."); } }
class PaymentContext {
    private PaymentStrategy strategy;
    public void setPaymentStrategy(PaymentStrategy strategy) { this.strategy = strategy; }
    public void executePayment(double amount) { strategy.pay(amount); }
}
public class Exercise8_Strategy {
    public static void run() {
        System.out.println("--- Exercise 8: Strategy Pattern ---");
        PaymentContext context = new PaymentContext();
        context.setPaymentStrategy(new CreditCardPayment());
        context.executePayment(50.0);
        context.setPaymentStrategy(new PayPalPayment());
        context.executePayment(75.0);
        System.out.println();
    }
}
