import java.util.HashMap;
import java.util.Map;

class Product {
    String productId;
    String productName;
    int quantity;
    double price;

    public Product(String productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" + "productId='" + productId + '\'' + ", productName='" + productName + '\'' + ", quantity=" + quantity + ", price=" + price + '}';
    }
}

public class InventoryManagementSystem {
    private Map<String, Product> inventory = new HashMap<>();

    public void addProduct(Product product) {
        inventory.put(product.productId, product);
    }

    public void updateProduct(String productId, int quantity, double price) {
        if (inventory.containsKey(productId)) {
            Product p = inventory.get(productId);
            p.quantity = quantity;
            p.price = price;
        } else {
            System.out.println("Product not found.");
        }
    }

    public void deleteProduct(String productId) {
        inventory.remove(productId);
    }

    public void display() {
        for (Product p : inventory.values()) {
            System.out.println(p);
        }
    }

    public static void run() {
        System.out.println("--- Exercise 1: Inventory Management System ---");
        InventoryManagementSystem ims = new InventoryManagementSystem();
        ims.addProduct(new Product("P01", "Laptop", 10, 1000.0));
        ims.addProduct(new Product("P02", "Mouse", 50, 20.0));
        ims.display();
        System.out.println("Updating P01...");
        ims.updateProduct("P01", 8, 950.0);
        ims.display();
        System.out.println("Deleting P02...");
        ims.deleteProduct("P02");
        ims.display();
        System.out.println();
    }
}
