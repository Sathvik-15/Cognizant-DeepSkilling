class Employee {
    String employeeId;
    String name;
    String position;
    double salary;

    public Employee(String employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{id='" + employeeId + "', name='" + name + "'}";
    }
}

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    public void addEmployee(Employee emp) {
        if (size < employees.length) {
            employees[size++] = emp;
        } else {
            System.out.println("Array full.");
        }
    }

    public Employee searchEmployee(String id) {
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId.equals(id)) return employees[i];
        }
        return null;
    }

    public void traverse() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployee(String id) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId.equals(id)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            for (int i = index; i < size - 1; i++) {
                employees[i] = employees[i + 1];
            }
            employees[size - 1] = null;
            size--;
        }
    }

    public static void run() {
        System.out.println("--- Exercise 4: Employee Management System ---");
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);
        ems.addEmployee(new Employee("E1", "John", "Dev", 5000));
        ems.addEmployee(new Employee("E2", "Jane", "Manager", 7000));
        ems.traverse();
        System.out.println("Search E1: " + ems.searchEmployee("E1"));
        ems.deleteEmployee("E1");
        ems.traverse();
        System.out.println();
    }
}
