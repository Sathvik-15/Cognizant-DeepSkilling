import java.util.Arrays;
import java.util.Comparator;

class Book {
    String bookId;
    String title;
    String author;

    public Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book{title='" + title + "', author='" + author + "'}";
    }
}

public class LibraryManagement {
    public static Book linearSearch(Book[] books, String title) {
        for (Book b : books) {
            if (b.title.equalsIgnoreCase(title)) return b;
        }
        return null;
    }

    public static Book binarySearch(Book[] books, String title) {
        int left = 0, right = books.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = books[mid].title.compareToIgnoreCase(title);
            if (cmp == 0) return books[mid];
            if (cmp < 0) left = mid + 1;
            else right = mid - 1;
        }
        return null;
    }

    public static void run() {
        System.out.println("--- Exercise 6: Library Management System ---");
        Book[] books = {
            new Book("B1", "Java Basics", "Author A"),
            new Book("B2", "Advanced Java", "Author B"),
            new Book("B3", "Spring Core", "Author C")
        };
        System.out.println("Linear Search 'Java Basics': " + linearSearch(books, "Java Basics"));
        
        Arrays.sort(books, Comparator.comparing(b -> b.title));
        System.out.println("Binary Search 'Spring Core': " + binarySearch(books, "Spring Core"));
        System.out.println();
    }
}
