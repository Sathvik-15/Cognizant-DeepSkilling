public class Main {
    public static void main(String[] args) {
        System.out.println("Executing All Data Structures Exercises\n====================================\n");
        InventoryManagementSystem.run();
        EcommerceSearch.run();
        SortingOrders.run();
        EmployeeManagementSystem.run();
        TaskManagementSystem.run();
        LibraryManagement.run();
        FinancialForecasting.run();
    }
}
