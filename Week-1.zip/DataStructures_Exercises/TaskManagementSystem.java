class Task {
    String taskId;
    String taskName;
    String status;

    public Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Task{id='" + taskId + "', name='" + taskName + "', status='" + status + "'}";
    }
}

class Node {
    Task task;
    Node next;
    public Node(Task task) { this.task = task; this.next = null; }
}

public class TaskManagementSystem {
    private Node head;

    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    public Task searchTask(String taskId) {
        Node temp = head;
        while (temp != null) {
            if (temp.task.taskId.equals(taskId)) return temp.task;
            temp = temp.next;
        }
        return null;
    }

    public void traverse() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.task);
            temp = temp.next;
        }
    }

    public void deleteTask(String taskId) {
        if (head == null) return;
        if (head.task.taskId.equals(taskId)) {
            head = head.next;
            return;
        }
        Node temp = head;
        while (temp.next != null && !temp.next.task.taskId.equals(taskId)) {
            temp = temp.next;
        }
        if (temp.next != null) {
            temp.next = temp.next.next;
        }
    }

    public static void run() {
        System.out.println("--- Exercise 5: Task Management System ---");
        TaskManagementSystem tms = new TaskManagementSystem();
        tms.addTask(new Task("T1", "Design", "Pending"));
        tms.addTask(new Task("T2", "Develop", "In Progress"));
        tms.traverse();
        System.out.println("Search T2: " + tms.searchTask("T2"));
        tms.deleteTask("T1");
        tms.traverse();
        System.out.println();
    }
}
