public class FinancialForecasting {
    public static double calculateFutureValue(double presentValue, double growthRate, int periods) {
        if (periods == 0) {
            return presentValue;
        }
        return calculateFutureValue(presentValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void run() {
        System.out.println("--- Exercise 7: Financial Forecasting ---");
        double pv = 1000.0;
        double rate = 0.05;
        int periods = 10;
        System.out.println("Present Value: " + pv + ", Rate: " + rate + ", Periods: " + periods);
        System.out.println("Future Value: " + calculateFutureValue(pv, rate, periods));
        System.out.println();
    }
}
