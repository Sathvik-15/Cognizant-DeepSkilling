import java.util.Arrays;
import java.util.Comparator;

class EProduct {
    String productId;
    String productName;
    String category;

    public EProduct(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }
    
    @Override
    public String toString() {
        return "EProduct{id='" + productId + "', name='" + productName + "', category='" + category + "'}";
    }
}

public class EcommerceSearch {
    public static EProduct linearSearch(EProduct[] products, String targetId) {
        for (EProduct p : products) {
            if (p.productId.equals(targetId)) return p;
        }
        return null;
    }

    public static EProduct binarySearch(EProduct[] products, String targetId) {
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = products[mid].productId.compareTo(targetId);
            if (cmp == 0) return products[mid];
            if (cmp < 0) left = mid + 1;
            else right = mid - 1;
        }
        return null;
    }

    public static void run() {
        System.out.println("--- Exercise 2: E-commerce Platform Search ---");
        EProduct[] products = {
            new EProduct("P03", "Keyboard", "Electronics"),
            new EProduct("P01", "Monitor", "Electronics"),
            new EProduct("P02", "Desk", "Furniture")
        };
        System.out.println("Linear Search for P02: " + linearSearch(products, "P02"));
        
        Arrays.sort(products, Comparator.comparing(p -> p.productId));
        System.out.println("Binary Search for P03: " + binarySearch(products, "P03"));
        System.out.println();
    }
}
