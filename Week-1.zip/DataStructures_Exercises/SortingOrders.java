class Order {
    String orderId;
    String customerName;
    double totalPrice;

    public Order(String orderId, String customerName, double totalPrice) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }

    @Override
    public String toString() {
        return "Order{id='" + orderId + "', price=" + totalPrice + "}";
    }
}

public class SortingOrders {
    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].totalPrice < orders[j + 1].totalPrice) { // descending
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].totalPrice;
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (orders[j].totalPrice > pivot) { // descending
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    public static void run() {
        System.out.println("--- Exercise 3: Sorting Customer Orders ---");
        Order[] orders1 = {new Order("O1", "Alice", 250.0), new Order("O2", "Bob", 150.0), new Order("O3", "Charlie", 300.0)};
        Order[] orders2 = {new Order("O1", "Alice", 250.0), new Order("O2", "Bob", 150.0), new Order("O3", "Charlie", 300.0)};

        bubbleSort(orders1);
        System.out.println("Bubble Sort (Descending): " + java.util.Arrays.toString(orders1));
        
        quickSort(orders2, 0, orders2.length - 1);
        System.out.println("Quick Sort (Descending): " + java.util.Arrays.toString(orders2));
        System.out.println();
    }
}
