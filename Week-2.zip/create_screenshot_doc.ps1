Add-Type -AssemblyName System.Drawing
$text = Get-Content -Path "d:\Cognizant\Week-2\output.txt" -Raw

[int]$width = 1100
[int]$height = 2000

$bmp = New-Object System.Drawing.Bitmap($width, $height)
$graphics = [System.Drawing.Graphics]::FromImage($bmp)
$graphics.Clear([System.Drawing.Color]::Black)

$font = New-Object System.Drawing.Font("Consolas", 14)
$brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::LightGray)
$rect = New-Object System.Drawing.RectangleF(30, 30, $width, $height)

$graphics.DrawString($text, $font, $brush, $rect)

$imagePath = "d:\Cognizant\Week-2\screenshot.png"
$bmp.Save($imagePath, [System.Drawing.Imaging.ImageFormat]::Png)

$graphics.Dispose()
$bmp.Dispose()
$font.Dispose()
$brush.Dispose()

# Create Word Document
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$doc = $word.Documents.Add()
$selection = $word.Selection

$selection.TypeText("Here is the screenshot of the output for both Week-2 projects:")
$selection.TypeParagraph()
$selection.TypeParagraph()
$selection.InlineShapes.AddPicture($imagePath)

$outputPath = "d:\Cognizant\Week-2\Screenshot_Outputs.docx"
$doc.SaveAs([ref]$outputPath)
$doc.Close()
$word.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($word) | Out-Null
