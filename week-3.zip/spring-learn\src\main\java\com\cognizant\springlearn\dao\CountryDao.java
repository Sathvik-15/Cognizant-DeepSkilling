package com.cognizant.springlearn.dao;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.exception.CountryNotFoundException;
import com.cognizant.springlearn.model.Country;

@Component
public class CountryDao {

    private static List<Country> COUNTRY_LIST;

    public CountryDao() {
        ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
        COUNTRY_LIST = context.getBean("countryList", java.util.ArrayList.class);
    }

    public List<Country> getAllCountries() {
        return COUNTRY_LIST;
    }

    public Country getCountry(String code) throws CountryNotFoundException {
        return COUNTRY_LIST.stream()
                .filter(country -> country.getCode().equalsIgnoreCase(code))
                .findFirst()
                .orElseThrow(() -> new CountryNotFoundException("Country not found"));
    }

    public void addCountry(Country country) {
        COUNTRY_LIST.add(country);
    }
}
