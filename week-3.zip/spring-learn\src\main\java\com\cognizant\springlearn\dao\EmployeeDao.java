package com.cognizant.springlearn.dao;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.exception.EmployeeNotFoundException;
import com.cognizant.springlearn.model.Employee;

@Component
public class EmployeeDao {

    private static List<Employee> EMPLOYEE_LIST;

    public EmployeeDao() {
        ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
        EMPLOYEE_LIST = context.getBean("employeeList", java.util.ArrayList.class);
    }

    public List<Employee> getAllEmployees() {
        return EMPLOYEE_LIST;
    }

    public void updateEmployee(Employee employee) throws EmployeeNotFoundException {
        Employee existingEmployee = EMPLOYEE_LIST.stream()
                .filter(e -> e.getId().equals(employee.getId()))
                .findFirst()
                .orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
        
        existingEmployee.setName(employee.getName());
        existingEmployee.setSalary(employee.getSalary());
        existingEmployee.setPermanent(employee.getPermanent());
        existingEmployee.setDateOfBirth(employee.getDateOfBirth());
        existingEmployee.setDepartment(employee.getDepartment());
    }

    public void deleteEmployee(Integer id) throws EmployeeNotFoundException {
        Employee existingEmployee = EMPLOYEE_LIST.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
        EMPLOYEE_LIST.remove(existingEmployee);
    }
}
