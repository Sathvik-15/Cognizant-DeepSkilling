import React, { useContext, useState } from 'react';
const ThemeContext = React.createContext('light');
const EmployeeCard = () => {
  const theme = useContext(ThemeContext);
  return <div style={{ background: theme === 'light' ? '#fff' : '#333', color: theme === 'light' ? '#000' : '#fff', padding: '20px', border: '1px solid gray' }}>Employee Details</div>;
};
const EmployeeList = () => <div><EmployeeCard /></div>;
const ThemeApp = () => {
  const [theme, setTheme] = useState('light');
  return (
    <ThemeContext.Provider value={theme}>
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <h2>Theme Context API (HOL 14)</h2>
        <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>Toggle Theme</button>
        <div style={{ marginTop: '20px' }}><EmployeeList /></div>
      </div>
    </ThemeContext.Provider>
  );
};
export default ThemeApp;
