import React from 'react';
import './CohortDashboard.css';
const CohortDashboard = () => (
  <div className="cohort-container">
    <h2>Ongoing and Completed Cohorts (HOL 5)</h2>
    <div className="cohort-card" style={{backgroundColor: '#e8f4f8'}}>React JS - Ongoing</div>
    <div className="cohort-card" style={{backgroundColor: '#f8e8e8'}}>Angular - Completed</div>
  </div>
);
export default CohortDashboard;
