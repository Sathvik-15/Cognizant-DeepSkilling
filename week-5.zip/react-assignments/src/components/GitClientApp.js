import React, { useState } from 'react';
import axios from 'axios';
const GitClientApp = () => {
  const [user, setUser] = useState('');
  const [repos, setRepos] = useState([]);
  
  const fetchRepos = async () => {
    try {
      const res = await axios.get(`https://api.github.com/users/${user}/repos`);
      setRepos(res.data);
    } catch (e) {
      alert('Error fetching repositories');
    }
  };
  
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>Git Client App (HOL 19)</h2>
      <input type="text" placeholder="GitHub Username" value={user} onChange={e => setUser(e.target.value)} />
      <button onClick={fetchRepos}>Fetch Repos</button>
      <ul style={{ textAlign: 'left', marginTop: '20px' }}>
        {repos.map(r => <li key={r.id}>{r.name}</li>)}
      </ul>
    </div>
  );
};
export default GitClientApp;
