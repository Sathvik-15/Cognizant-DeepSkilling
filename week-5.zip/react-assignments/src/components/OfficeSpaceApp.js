import React from 'react';
const offices = [
  { Name: 'Davo Workspace', Rent: 50000, Address: 'Chennai' },
  { Name: 'Prime Office', Rent: 70000, Address: 'Bangalore' }
];
const OfficeSpaceApp = () => (
  <div style={{ padding: '20px', textAlign: 'center' }}>
    <h2>Office Space Rental (HOL 10)</h2>
    <img src="https://via.placeholder.com/300x150" alt="Office Space" />
    <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginTop: '20px' }}>
      {offices.map((office, idx) => (
        <div key={idx} style={{ border: '1px solid #ccc', padding: '20px', borderRadius: '8px' }}>
          <h3>{office.Name}</h3>
          <p>Address: {office.Address}</p>
          <p style={{ color: office.Rent < 60000 ? 'red' : 'green', fontWeight: 'bold' }}>Rent: {office.Rent}</p>
        </div>
      ))}
    </div>
  </div>
);
export default OfficeSpaceApp;
