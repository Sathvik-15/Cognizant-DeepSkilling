import React, { useState } from 'react';
const TicketRaisingApp = () => {
  const [name, setName] = useState('');
  const [complaint, setComplaint] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    const ref = Math.floor(Math.random() * 1000000);
    alert(`Complaint raised successfully! Reference Number: ${ref}`);
  };
  
  return (
    <div style={{ padding: '20px', textAlign: 'center', maxWidth: '400px', margin: 'auto' }}>
      <h2>Ticket Raising (HOL 15)</h2>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <input type="text" placeholder="Employee Name" required value={name} onChange={e => setName(e.target.value)} />
        <textarea placeholder="Complaint details" required rows="4" value={complaint} onChange={e => setComplaint(e.target.value)}></textarea>
        <button type="submit">Submit Complaint</button>
      </form>
    </div>
  );
};
export default TicketRaisingApp;
