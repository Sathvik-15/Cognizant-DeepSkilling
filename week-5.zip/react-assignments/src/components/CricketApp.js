import React from 'react';
import './CricketApp.css';

const players = [
  { name: 'Virat Kohli', role: 'Batsman', average: 59.3 },
  { name: 'Jasprit Bumrah', role: 'Bowler', average: 21.9 },
  { name: 'Rohit Sharma', role: 'Batsman', average: 48.9 },
  { name: 'Ravindra Jadeja', role: 'All-rounder', average: 32.5 }
];

const CricketApp = () => {
  return (
    <div className="cricket-container">
      <h2>Indian Cricket Team (HOL 9)</h2>
      <div className="players-list">
        {players.map(({ name, role, average }, index) => (
          <div key={index} className="player-card">
            <h3>{name}</h3>
            <p><strong>Role:</strong> {role}</p>
            <p><strong>Average:</strong> {average}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CricketApp;
