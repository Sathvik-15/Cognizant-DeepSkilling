import React, { useState } from 'react';
const MailRegisterApp = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    if (form.name.length < 5) { setError('Name must be at least 5 characters'); return; }
    if (!form.email.includes('@') || !form.email.includes('.')) { setError('Invalid email'); return; }
    if (form.password.length < 8) { setError('Password must be at least 8 characters'); return; }
    setError('');
    alert('Registered Successfully!');
  };
  
  return (
    <div style={{ padding: '20px', textAlign: 'center', maxWidth: '400px', margin: 'auto' }}>
      <h2>Mail Register (HOL 16)</h2>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <input type="text" placeholder="Name" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
        <input type="email" placeholder="Email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
        <input type="password" placeholder="Password" value={form.password} onChange={e => setForm({...form, password: e.target.value})} />
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit">Register</button>
      </form>
    </div>
  );
};
export default MailRegisterApp;
