import React, { useState } from 'react';
const BookDetails = () => <div><h3>Book Details</h3><p>React Programming Guide</p></div>;
const BlogDetails = () => <div><h3>Blog Details</h3><p>Top 10 React Tips</p></div>;
const CourseDetails = () => <div><h3>Course Details</h3><p>Mastering ReactJS</p></div>;

const BloggerApp = () => {
  const [view, setView] = useState('book');
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>Blogger App (HOL 13)</h2>
      <button onClick={() => setView('book')}>Books</button>
      <button onClick={() => setView('blog')}>Blogs</button>
      <button onClick={() => setView('course')}>Courses</button>
      <div style={{ marginTop: '20px' }}>
        {view === 'book' && <BookDetails />}
        {view === 'blog' && <BlogDetails />}
        {view === 'course' && <CourseDetails />}
      </div>
    </div>
  );
};
export default BloggerApp;
