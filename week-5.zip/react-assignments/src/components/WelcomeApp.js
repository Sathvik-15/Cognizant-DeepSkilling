import React from 'react';
const WelcomeApp = () => (
  <div style={{ textAlign: 'center', padding: '2rem' }}>
    <h2>Welcome to the first session of React (HOL 1-4)</h2>
  </div>
);
export default WelcomeApp;
