import React, { useState } from 'react';
const TicketBookingApp = () => {
  const [loggedIn, setLoggedIn] = useState(false);
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>Ticket Booking App (HOL 12)</h2>
      {loggedIn ? (
        <div>
          <h3>User Page: You can book tickets here!</h3>
          <button onClick={() => setLoggedIn(false)}>Logout</button>
        </div>
      ) : (
        <div>
          <h3>Guest Page: Browse flight details. Log in to book.</h3>
          <button onClick={() => setLoggedIn(true)}>Login</button>
        </div>
      )}
    </div>
  );
};
export default TicketBookingApp;
