import React, { useState } from 'react';
const EventExamplesApp = () => {
  const [count, setCount] = useState(0);
  const [currency, setCurrency] = useState(0);
  
  const handleIncrement = () => {
    setCount(count + 1);
    alert('Say Hello! Value incremented.');
  };
  
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>Event Examples (HOL 11)</h2>
      <p>Count: {count}</p>
      <button onClick={handleIncrement} style={{ margin: '5px' }}>Increment</button>
      <button onClick={() => setCount(count - 1)} style={{ margin: '5px' }}>Decrement</button>
      <button onClick={() => alert('Welcome')} style={{ margin: '5px' }}>Say Welcome</button>
      <button onClick={() => alert('I was clicked')} style={{ margin: '5px' }}>OnPress</button>
      
      <div style={{ marginTop: '20px' }}>
        <input type="number" onChange={(e) => setCurrency(e.target.value)} placeholder="Enter INR" />
        <button onClick={() => alert(`Euro: ${(currency / 90).toFixed(2)}`)}>Convert to Euro</button>
      </div>
    </div>
  );
};
export default EventExamplesApp;
