import React from 'react';
import './FetchUserApp.css';

class Getuser extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      user: null,
      loading: true,
      error: null
    };
  }

  componentDidMount() {
    fetch('https://api.randomuser.me/')
      .then(response => response.json())
      .then(data => {
        this.setState({
          user: data.results[0],
          loading: false
        });
      })
      .catch(err => {
        this.setState({
          error: err.message,
          loading: false
        });
      });
  }

  render() {
    const { user, loading, error } = this.state;

    return (
      <div className="fetch-container">
        <h2>Fetch User (HOL 17)</h2>
        {loading && <p>Loading user data...</p>}
        {error && <p>Error: {error}</p>}
        {user && (
          <div className="user-card">
            <img src={user.picture.large} alt="User profile" className="user-img" />
            <div className="user-info">
              <h3>{user.name.title} {user.name.first} {user.name.last}</h3>
              <p>Email: {user.email}</p>
              <p>Location: {user.location.city}, {user.location.country}</p>
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default Getuser;
