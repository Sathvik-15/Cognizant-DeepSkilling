import React from 'react';
import { Link } from 'react-router-dom';
import './Dashboard.css';

const Dashboard = () => {
  const exercises = [
    { path: '/welcome', title: 'Welcome (HOL 1-4)' },
    { path: '/cohorts', title: 'Cohort Dashboard (HOL 5)' },
    { path: '/shopping', title: 'Shopping App (HOL 7)' },
    { path: '/counter', title: 'Counter App (HOL 8)' },
    { path: '/cricket', title: 'Cricket App (HOL 9)' },
    { path: '/office', title: 'Office Space Rental (HOL 10)' },
    { path: '/events', title: 'Event Examples (HOL 11)' },
    { path: '/booking', title: 'Ticket Booking App (HOL 12)' },
    { path: '/blogger', title: 'Blogger App (HOL 13)' },
    { path: '/theme', title: 'Context Theme App (HOL 14)' },
    { path: '/ticket-raise', title: 'Ticket Raising App (HOL 15)' },
    { path: '/register', title: 'Mail Register App (HOL 16)' },
    { path: '/fetch-user', title: 'Fetch User App (HOL 17)' },
    { path: '/git-client', title: 'Git Client App (HOL 19)' }
  ];

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1>React Assignments - All 19 Exercises</h1>
        <p>A consolidated application containing all hands-on exercises.</p>
      </header>
      <div className="card-grid">
        {exercises.map((ex, index) => (
          <Link to={ex.path} key={index} className="exercise-card">
            <h2>{ex.title}</h2>
            <div className="card-footer">View Exercise &rarr;</div>
          </Link>
        ))}
      </div>
    </div>
  );
};
export default Dashboard;
