import React from 'react';
import './CounterApp.css';

class CountPeople extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      entrycount: 0,
      exitcount: 0
    };
  }

  updateEntry = () => {
    this.setState((prevState) => ({
      entrycount: prevState.entrycount + 1
    }));
  };

  updateExit = () => {
    this.setState((prevState) => ({
      exitcount: prevState.exitcount + 1
    }));
  };

  render() {
    return (
      <div className="counter-container">
        <h2>Count People (HOL 8)</h2>
        <div className="counter-stats">
          <div className="stat-box login">
            <h3>Entered</h3>
            <p className="count-number">{this.state.entrycount}</p>
            <button onClick={this.updateEntry} className="btn login-btn">Login</button>
          </div>
          <div className="stat-box exit">
            <h3>Exited</h3>
            <p className="count-number">{this.state.exitcount}</p>
            <button onClick={this.updateExit} className="btn exit-btn">Exit</button>
          </div>
        </div>
      </div>
    );
  }
}

export default CountPeople;
