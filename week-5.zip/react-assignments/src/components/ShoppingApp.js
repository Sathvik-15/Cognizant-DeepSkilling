import React from 'react';
import './ShoppingApp.css';

class Cart extends React.Component {
  render() {
    return (
      <div className="cart-item">
        <span className="item-name">{this.props.item.Itemname}</span>
        <span className="item-price">Rs. {this.props.item.Price}</span>
      </div>
    );
  }
}

class OnlineShopping extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      cartItems: [
        { Itemname: 'Laptop', Price: 50000 },
        { Itemname: 'Mobile', Price: 20000 },
        { Itemname: 'Headphones', Price: 2000 },
        { Itemname: 'Keyboard', Price: 1000 },
        { Itemname: 'Mouse', Price: 500 }
      ]
    };
  }

  render() {
    return (
      <div className="shopping-container">
        <h2>Online Shopping (HOL 7)</h2>
        <div className="cart-list">
          {this.state.cartItems.map((item, index) => (
            <Cart key={index} item={item} />
          ))}
        </div>
      </div>
    );
  }
}

export default OnlineShopping;
