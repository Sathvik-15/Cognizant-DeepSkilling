import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import ShoppingApp from './components/ShoppingApp';
import CounterApp from './components/CounterApp';
import FetchUserApp from './components/FetchUserApp';
import CricketApp from './components/CricketApp';
import WelcomeApp from './components/WelcomeApp';
import CohortDashboard from './components/CohortDashboard';
import OfficeSpaceApp from './components/OfficeSpaceApp';
import EventExamplesApp from './components/EventExamplesApp';
import TicketBookingApp from './components/TicketBookingApp';
import BloggerApp from './components/BloggerApp';
import ThemeApp from './components/ThemeApp';
import TicketRaisingApp from './components/TicketRaisingApp';
import MailRegisterApp from './components/MailRegisterApp';
import GitClientApp from './components/GitClientApp';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/welcome" element={<WelcomeApp />} />
          <Route path="/cohorts" element={<CohortDashboard />} />
          <Route path="/shopping" element={<ShoppingApp />} />
          <Route path="/counter" element={<CounterApp />} />
          <Route path="/cricket" element={<CricketApp />} />
          <Route path="/office" element={<OfficeSpaceApp />} />
          <Route path="/events" element={<EventExamplesApp />} />
          <Route path="/booking" element={<TicketBookingApp />} />
          <Route path="/blogger" element={<BloggerApp />} />
          <Route path="/theme" element={<ThemeApp />} />
          <Route path="/ticket-raise" element={<TicketRaisingApp />} />
          <Route path="/register" element={<MailRegisterApp />} />
          <Route path="/fetch-user" element={<FetchUserApp />} />
          <Route path="/git-client" element={<GitClientApp />} />
          <Route path="*" element={<Dashboard />} />
        </Routes>
      </div>
    </Router>
  );
}
export default App;
